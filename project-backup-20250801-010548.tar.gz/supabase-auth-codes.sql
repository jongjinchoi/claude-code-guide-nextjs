-- 인증 코드 테이블 생성
CREATE TABLE IF NOT EXISTS auth_codes (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) NOT NULL,
  code VARCHAR(6) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  used BOOLEAN DEFAULT FALSE
);

-- 인덱스 생성
CREATE INDEX idx_auth_codes_email ON auth_codes(email);
CREATE INDEX idx_auth_codes_code ON auth_codes(code);
CREATE INDEX idx_auth_codes_expires_at ON auth_codes(expires_at);

-- RLS 활성화
ALTER TABLE auth_codes ENABLE ROW LEVEL SECURITY;

-- 정책 생성
CREATE POLICY "Enable insert for all users" ON auth_codes
FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY "Enable select for all users" ON auth_codes
FOR SELECT TO anon USING (true);

CREATE POLICY "Enable update for all users" ON auth_codes
FOR UPDATE TO anon USING (true);

-- 만료된 코드 자동 삭제 함수 (선택사항)
CREATE OR REPLACE FUNCTION delete_expired_auth_codes()
RETURNS void AS $$
BEGIN
  DELETE FROM auth_codes WHERE expires_at < NOW();
END;
$$ LANGUAGE plpgsql;