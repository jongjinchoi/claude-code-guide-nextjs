# File Usage Verification Report

## Summary

After thorough verification, most files that appeared "unused" by simple grep searches are actually being used through special mechanisms in Next.js or imported through CSS cascade.

## Categories of Files and Their Usage

### 1. Next.js Pages (Automatically Routed)
These files are used by Next.js routing system and don't need explicit imports:

- ✅ `./app/about/page.tsx` - Accessible at `/about`
- ✅ `./app/faq/page.tsx` - Accessible at `/faq`
- ✅ `./app/guide/page.tsx` - Accessible at `/guide`
- ✅ `./app/dashboard/page.tsx` - Accessible at `/dashboard`
- ✅ `./app/dashboard-login/page.tsx` - Accessible at `/dashboard-login`
- ✅ `./app/guide-test/page.tsx` - Accessible at `/guide-test`
- ✅ All `layout.tsx` files - Used by Next.js for layout nesting

### 2. API Routes (HTTP Endpoints)
These files are API endpoints accessed via HTTP requests:

- ✅ `./app/api/counter/route.ts` - Called from `useCounter.ts`
- ✅ `./app/api/guide-tracking/route.ts` - Called from `useGuideTracking.ts`
- ✅ `./app/api/dashboard-auth/route.ts` - Authentication endpoint
- ✅ `./app/api/send-auth-code/route.ts` - Auth code sending
- ✅ `./app/api/verify-auth-code/route.ts` - Auth code verification

### 3. CSS Files (Cascaded Imports)
These CSS files are imported through the cascade system:

- ✅ `./app/styles/components/guide/step-base.css` - Imported via `guide-step-imports.css`
- ✅ `./app/styles/components/guide/step-*.css` - All imported via `guide-step-imports.css`
- ✅ `./app/styles/components/guide/terminal/*.css` - All imported via `guide-step-imports.css`

The import chain is:
```
guide/page.tsx → guide-step-imports.css → individual CSS modules
```

### 4. Truly Unused Files

#### Components
- ❌ `./app/components/ClaudeCodeREPL.tsx` - Not imported anywhere
- ❌ `./app/components/common/Badge.tsx` - Not imported anywhere
- ❌ `./app/components/ThemeScript.tsx` - Not imported anywhere
- ❌ `./app/contexts/ToastContext.tsx` - Toast.tsx has its own context

#### Backup Directories (Can be safely removed)
- `./app/faq_backup_20250731_132840/` - Backup from July 31
- `./app/guide/components/_backup_before_refactor/` - Old component backups
- `./app/guide/components/_backup_old_step_components/` - Old component backups
- `./app/styles/_backup_before_refactor/` - Old CSS backups
- `./app/styles/_backup_unused_css/` - Unused CSS backups
- `./backup/` - General backup directory with 68 files

### 5. Files Used by Backup Code Only
- `./app/lib/modules/supabase-client.ts` - Only imported by files in backup directories
- `./app/lib/utils/device-info.ts` - Not imported anywhere in active code
- `./app/types/analytics-minimal.ts` - Not imported anywhere

## Recommendations

### Safe to Delete
1. All backup directories and their contents
2. Truly unused components:
   - `ClaudeCodeREPL.tsx`
   - `Badge.tsx`
   - `ThemeScript.tsx`
   - `ToastContext.tsx` (since Toast.tsx has its own)

### Keep But Monitor
1. `supabase-client.ts` - May be needed if analytics are re-enabled
2. `device-info.ts` - May be useful for future features
3. `guide-test/page.tsx` - Useful for testing

### Action Items
1. Remove backup directories to clean up the project
2. Consider removing truly unused components
3. Document why certain files are kept for future reference

## Verification Commands

To verify file usage in the future, use these commands:

```bash
# Check Next.js pages
find ./app -name "page.tsx" -o -name "layout.tsx"

# Check API routes
find ./app/api -name "route.ts"

# Check CSS imports cascade
grep -r "@import" ./app/styles --include="*.css"

# Check component imports
grep -r "from.*ComponentName" . --include="*.tsx" --exclude-dir=node_modules
```