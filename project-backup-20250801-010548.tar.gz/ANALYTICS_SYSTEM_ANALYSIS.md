# 기존 Analytics 시스템 상세 분석 보고서

## 📅 분석 날짜: 2025년 7월 31일

## 📊 전체 시스템 구조

### 1. 기존 Analytics 시스템 (복잡한 구조)
```
app/lib/analytics/AnalyticsService.ts (658줄)
├── EventDeduplicator 클래스
├── SmartBatcher 클래스  
├── StepTracker 클래스
├── AnalyticsService 클래스
└── Supabase 통합
```

### 2. 새로운 Guide Tracking 시스템 (단순한 구조)
```
app/hooks/useGuideTracking.ts (207줄)
├── 세션 추적
├── 단계 진행 추적
├── 에러 추적
└── 완료 추적
```

## 🔍 상세 파일 분석

### 1. **현재 사용 중인 파일**

#### a) `app/components/AnalyticsProvider.tsx`
- **용도**: 페이지 레벨 이벤트 자동 추적
- **기능**: page_exit, page_blur 이벤트 추적
- **사용 위치**: app/layout.tsx에서 전역으로 사용
- **판단**: ⚠️ **유지 필요** (페이지 체류 시간 추적에 사용)

#### b) `app/lib/analytics/AnalyticsService.ts` (658줄)
- **용도**: 복잡한 이벤트 처리 시스템
- **주요 기능**:
  - EventDeduplicator: 중복 이벤트 제거
  - SmartBatcher: 배치 처리 (100개씩)
  - StepTracker: 가이드 단계 추적
  - Supabase/Google Sheets 동시 전송
- **문제점**:
  - 과도하게 복잡한 구조
  - 26개 컬럼 raw_events 테이블 사용
  - 불필요한 최적화 (중복 제거, 배치 처리)
- **판단**: ❌ **제거 가능** (새 시스템으로 대체됨)

#### c) `app/types/analytics.ts`
- **용도**: Analytics 관련 타입 정의
- **사용 여부**: AnalyticsProvider에서 사용 중
- **판단**: ⚠️ **수정 필요** (필요한 타입만 유지)

### 2. **사용하지 않는 파일**

#### a) `app/hooks/useAnalytics.ts` (135줄)
- **용도**: Analytics 훅
- **사용 여부**: 어디서도 import되지 않음
- **판단**: ❌ **제거**

#### b) `app/hooks/useAnalyticsNoSuspense.ts`
- **용도**: Suspense 없는 Analytics 훅
- **사용 여부**: 사용하지 않음
- **판단**: ❌ **제거**

#### c) `app/lib/modules/analytics.ts` (27줄)
- **용도**: 레거시 Analytics 래퍼
- **사용 여부**: 사용하지 않음
- **판단**: ❌ **제거**

#### d) `app/lib/analytics/event-schemas.ts`
- **용도**: 이벤트 스키마 정의
- **사용 여부**: 사용하지 않음
- **판단**: ❌ **제거**

#### e) `app/lib/analytics/improved-extraction.ts`
- **용도**: 데이터 추출 개선
- **사용 여부**: 사용하지 않음
- **판단**: ❌ **제거**

## 📈 시스템 비교

### 기존 시스템 (AnalyticsService)
- **장점**:
  - 정교한 중복 제거
  - 배치 처리로 네트워크 최적화
  - 다양한 이벤트 타입 지원

- **단점**:
  - 과도한 복잡성 (658줄)
  - 26개 컬럼의 복잡한 데이터 구조
  - 유지보수 어려움
  - 실제 필요하지 않은 기능들

### 새 시스템 (useGuideTracking)
- **장점**:
  - 단순하고 명확한 구조 (207줄)
  - 필요한 기능만 구현
  - guide_sessions 테이블 사용 (간단한 구조)
  - 유지보수 용이

- **단점**:
  - 가이드 페이지 전용 (범용성 부족)

## 🎯 권장 사항

### 1. **즉시 제거 가능한 파일** (백업 후 삭제)
```bash
# 사용하지 않는 파일들
app/hooks/useAnalytics.ts
app/hooks/useAnalyticsNoSuspense.ts
app/lib/modules/analytics.ts
app/lib/analytics/event-schemas.ts
app/lib/analytics/improved-extraction.ts
app/lib/analytics/AnalyticsService.ts
```

### 2. **수정이 필요한 파일**
- `app/types/analytics.ts`: 필요한 타입만 남기고 정리
- `app/components/AnalyticsProvider.tsx`: 단순화 가능

### 3. **보관할 파일**
- `app/hooks/useGuideTracking.ts`: 새로운 추적 시스템
- `app/api/guide-tracking/route.ts`: API 엔드포인트

## 💾 데이터 마이그레이션
- 기존 raw_events (26컬럼) → guide_sessions (간단한 구조)
- 이미 guide_sessions 테이블로 전환 완료
- 기존 데이터는 Google Sheets에 백업됨

## 🔧 정리 후 효과
- 코드 라인 수: ~1,000줄 → ~300줄 (70% 감소)
- 복잡도: 대폭 감소
- 유지보수성: 크게 향상
- 성능: 불필요한 처리 제거로 개선

## 결론
기존의 복잡한 Analytics 시스템은 over-engineering의 전형적인 예시입니다. 
새로운 Guide Tracking 시스템이 실제 필요한 기능을 더 효율적으로 제공하고 있으므로,
기존 시스템은 백업 후 제거하는 것이 좋습니다.