#!/bin/bash

# Enhanced script to verify if files are truly unused
# This script checks for various usage patterns that simple grep might miss

echo "Verifying file usage patterns..."
echo "==============================="
echo

# Function to check if a file is a Next.js page
check_nextjs_page() {
    local file="$1"
    
    # Check if it's a page.tsx or layout.tsx in the app directory
    if [[ "$file" =~ app/.*/page\.tsx$ ]] || [[ "$file" =~ app/.*/layout\.tsx$ ]]; then
        # These are automatically used by Next.js routing
        return 0
    fi
    
    return 1
}

# Function to check if a file is an API route
check_api_route() {
    local file="$1"
    
    # Check if it's a route.ts in the app/api directory
    if [[ "$file" =~ app/api/.*/route\.ts$ ]]; then
        # These are API endpoints used via HTTP requests
        return 0
    fi
    
    return 1
}

# Function to check CSS imports in globals.css
check_css_imports() {
    local file="$1"
    local filename=$(basename "$file")
    
    # Check if it's imported in globals.css
    if grep -F "$filename" ./app/styles/globals.css >/dev/null 2>&1; then
        return 0
    fi
    
    # Check if it's imported via @import
    if grep "@import.*$filename" ./app/styles/globals.css >/dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

# Function to check dynamic imports
check_dynamic_imports() {
    local file="$1"
    local filename_no_ext="${file%.*}"
    
    # Check for dynamic imports
    if grep -r "import(.*['\"].*$(basename "$filename_no_ext")['\"]" . --include="*.ts" --include="*.tsx" --exclude-dir=node_modules --exclude-dir=.next >/dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

# Function to check if file is referenced in configuration
check_config_references() {
    local file="$1"
    local filename=$(basename "$file")
    
    # Check next.config.ts, tsconfig.json, etc.
    if grep -F "$filename" ./next.config.ts ./tsconfig.json ./package.json 2>/dev/null | grep -v "^Binary" >/dev/null; then
        return 0
    fi
    
    return 1
}

# Main verification
files_to_check=(
    "./app/about/page.tsx"
    "./app/faq/page.tsx"
    "./app/guide/page.tsx"
    "./app/api/counter/route.ts"
    "./app/api/guide-tracking/route.ts"
    "./app/lib/modules/supabase-client.ts"
    "./app/contexts/ToastContext.tsx"
    "./app/styles/components/guide/step-base.css"
)

echo "Checking specific files for usage patterns:"
echo

for file in "${files_to_check[@]}"; do
    echo "Checking: $file"
    
    if check_nextjs_page "$file"; then
        echo "  ✓ Next.js page (automatically routed)"
        continue
    fi
    
    if check_api_route "$file"; then
        echo "  ✓ API route (accessed via HTTP)"
        # Let's also check if it's called from the frontend
        endpoint=$(echo "$file" | sed 's|./app||' | sed 's|/route.ts||')
        if grep -r "fetch.*['\"]$endpoint['\"]" . --include="*.ts" --include="*.tsx" --exclude-dir=node_modules >/dev/null 2>&1; then
            echo "    - Called from frontend code"
        fi
        continue
    fi
    
    if [[ "$file" == *.css ]]; then
        if check_css_imports "$file"; then
            echo "  ✓ Imported in globals.css"
            continue
        fi
    fi
    
    # Check standard imports
    filename=$(basename "$file")
    filename_no_ext="${filename%.*}"
    
    import_count=$(grep -r "from ['\"].*$filename_no_ext['\"]" . --include="*.ts" --include="*.tsx" --exclude-dir=node_modules --exclude-dir=.next 2>/dev/null | wc -l)
    
    if [ $import_count -gt 0 ]; then
        echo "  ✓ Imported $import_count times"
        # Show where it's imported
        grep -r "from ['\"].*$filename_no_ext['\"]" . --include="*.ts" --include="*.tsx" --exclude-dir=node_modules --exclude-dir=.next 2>/dev/null | head -3 | sed 's/^/    - /'
    else
        echo "  ⚠️  No direct imports found"
        
        # Check for dynamic imports
        if check_dynamic_imports "$file"; then
            echo "    - Has dynamic imports"
        fi
        
        # Check config references
        if check_config_references "$file"; then
            echo "    - Referenced in configuration"
        fi
    fi
    
    echo
done

echo "\nChecking backup directories:"
echo "============================"
backup_dirs=$(find . -type d -name "*backup*" -o -name "_backup*" | grep -v node_modules)
echo "$backup_dirs" | while read dir; do
    if [ -n "$dir" ]; then
        file_count=$(find "$dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.css" \) 2>/dev/null | wc -l)
        echo "$dir: $file_count files"
    fi
done

echo "\nNote: Backup directories can typically be safely removed if no longer needed."