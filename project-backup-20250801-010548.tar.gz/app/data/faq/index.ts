// FAQ 페이지의 모든 데이터를 한 곳에서 export
export { faqSections } from './sections';
export { structuredData } from './structuredData';