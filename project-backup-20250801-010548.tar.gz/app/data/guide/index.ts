// Guide 페이지의 모든 데이터를 한 곳에서 export
export { macSteps, windowsSteps, guideSteps } from './steps';
export { GUIDE_CONSTANTS, STEP_NUMBER_MAP, OS_DEFAULTS } from './constants';