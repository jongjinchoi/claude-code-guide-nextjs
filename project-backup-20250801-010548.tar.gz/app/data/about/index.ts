// About 페이지의 모든 데이터를 한 곳에서 export
export { introContent } from './intro';
export { targetUsers } from './targetUsers';
export { featureCards } from './features';
export { faqItems } from './faq';
export { authorInfo } from './author';