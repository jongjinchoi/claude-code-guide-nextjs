# Unused Files Report for claude-code-guide-react

## Executive Summary

After thorough analysis, I found:
- **76 potentially unused files** (including backups)
- **49 backup files** that can be safely deleted
- **4 truly unused components**
- **1 duplicate component file**
- **3 unused library/utility files**

## Categories of Unused Files

### 1. 🗑️ Backup Directories (49 files total) - SAFE TO DELETE

#### Complete backup directories:
- `./app/faq_backup_20250731_132840/` - Backup from July 31, 2025
- `./app/guide/components/_backup_before_refactor/` - Old guide component backups
- `./app/guide/components/_backup_old_step_components/` - Another set of old components
- `./app/styles/_backup_before_refactor/` - Old CSS structure backups
- `./app/styles/_backup_unused_css/` - Already identified as unused CSS

#### Individual backup files:
- `./app/styles/components/_backup_guide-header.css`
- `./app/styles/components/_backup_section-common.css`

### 2. 🚫 Truly Unused Components (4 files)

These components are not imported anywhere in the active codebase:

1. **`./app/components/ClaudeCodeREPL.tsx`** (+ its CSS file)
   - Not imported by any file
   - Appears to be an unused REPL component

2. **`./app/components/common/Badge.tsx`** (+ its CSS file)
   - Not imported by any file
   - Common UI component that was never used

3. **`./app/components/ThemeScript.tsx`**
   - Not imported by any file
   - Theme functionality exists in ThemeProvider.tsx instead

4. **`./app/contexts/ToastContext.tsx`**
   - Not imported by any file
   - Toast.tsx component has its own built-in context

### 3. 📁 Duplicate Files (1 file)

- **`./components/ReturnToGuide.tsx`**
  - This is an older, simpler version
  - The active version is in `./app/components/ReturnToGuide.tsx`
  - FAQ page imports from the correct location (@/app/components/ReturnToGuide)
  - **Safe to delete** the duplicate in ./components/

### 4. 📚 Unused Library/Utility Files (3 files)

1. **`./app/lib/modules/supabase-client.ts`**
   - Only imported by files in backup directories
   - Might be kept if analytics are re-enabled

2. **`./app/lib/utils/device-info.ts`**
   - Not imported anywhere in active code
   - Utility for device detection

3. **`./app/types/analytics-minimal.ts`**
   - Not imported anywhere
   - Appears to be a simplified analytics type definition

### 5. 🧪 Test/Development Files (1 file)

- **`./app/guide-test/page.tsx`**
  - Test page accessible at `/guide-test`
  - Consider keeping for development/testing purposes

## Recommendations

### Immediate Actions (Safe to Delete):

1. **Delete all backup directories** (49 files)
   ```bash
   rm -rf ./app/faq_backup_20250731_132840
   rm -rf ./app/guide/components/_backup_before_refactor
   rm -rf ./app/guide/components/_backup_old_step_components
   rm -rf ./app/styles/_backup_before_refactor
   rm -rf ./app/styles/_backup_unused_css
   rm -f ./app/styles/components/_backup_guide-header.css
   rm -f ./app/styles/components/_backup_section-common.css
   ```

2. **Delete unused components** (7 files)
   ```bash
   rm -f ./app/components/ClaudeCodeREPL.tsx
   rm -f ./app/components/ClaudeCodeREPL.module.css
   rm -f ./app/components/common/Badge.tsx
   rm -f ./app/components/common/Badge.module.css
   rm -f ./app/components/ThemeScript.tsx
   rm -f ./app/contexts/ToastContext.tsx
   rm -f ./components/ReturnToGuide.tsx
   ```

### Consider for Future Use:

1. **Keep but monitor:**
   - `supabase-client.ts` - May be needed if analytics are re-enabled
   - `device-info.ts` - Useful utility for future features
   - `guide-test/page.tsx` - Useful for testing

## File Count Summary

- **Total unused files: 76**
- **Backup files to delete: 49**
- **Component files to delete: 7**
- **Duplicate files to delete: 1**
- **Files to keep but monitor: 3**

## Cleanup Script

Save and run this script to clean up all identified unused files:

```bash
#!/bin/bash
# cleanup_unused_files.sh

echo "Removing backup directories..."
rm -rf ./app/faq_backup_20250731_132840
rm -rf ./app/guide/components/_backup_before_refactor
rm -rf ./app/guide/components/_backup_old_step_components
rm -rf ./app/styles/_backup_before_refactor
rm -rf ./app/styles/_backup_unused_css
rm -f ./app/styles/components/_backup_guide-header.css
rm -f ./app/styles/components/_backup_section-common.css

echo "Removing unused components..."
rm -f ./app/components/ClaudeCodeREPL.tsx
rm -f ./app/components/ClaudeCodeREPL.module.css
rm -f ./app/components/common/Badge.tsx
rm -f ./app/components/common/Badge.module.css
rm -f ./app/components/ThemeScript.tsx
rm -f ./app/contexts/ToastContext.tsx
rm -f ./components/ReturnToGuide.tsx

echo "Cleanup complete!"
```

## Notes

- The count of "76 unused files" includes many files in backup directories
- Most apparently "unused" CSS files are actually imported through the cascade system
- Next.js pages and API routes don't need explicit imports
- Some files marked as unused might be referenced in ways not detected by simple grep searches