# 현재 Analytics 시스템 상세 분석 보고서

## 📅 분석 날짜: 2025년 7월 31일

## 🏗️ 시스템 아키텍처

### 1. **2개의 독립적인 추적 시스템**

```
┌─────────────────────────────────────────────────────────────┐
│                    전체 사이트 Analytics                      │
├─────────────────────────────┬───────────────────────────────┤
│   Google Analytics (GA4)    │    Guide Tracking System      │
│   - 모든 페이지 추적        │    - Guide 페이지 전용        │
│   - 일반적인 웹 분석        │    - 상세한 행동 분석         │
└─────────────────────────────┴───────────────────────────────┘
```

## 📊 1. Google Analytics (GA4) 시스템

### 구성 요소:
1. **app/layout.tsx**
   - GA4 스크립트 로드 (G-2XGK1CF366)
   - 전역 gtag 함수 초기화

2. **app/components/AnalyticsProvider.tsx**
   - 페이지 체류 시간 추적
   - page_exit, page_blur 이벤트
   - 전체 페이지에 자동 적용

### 추적되는 이벤트:
```javascript
// AnalyticsProvider.tsx
- page_exit: {
    time_on_page: number,      // 초 단위
    page_path: string,         // 현재 경로
    exit_type: string          // beforeunload | visibility_hidden | navigation
  }

- page_blur: {
    time_on_page: number,
    page_path: string
  }
```

### 작동 방식:
```javascript
// 페이지 진입 시
const pageLoadTime = Date.now();

// 페이지 떠날 때
const duration = Math.round((Date.now() - pageLoadTime) / 1000);
window.gtag('event', 'page_exit', { time_on_page: duration, ... });
```

## 🎯 2. Guide Tracking System (가이드 전용)

### 구성 요소:

#### a) **Frontend - useGuideTracking Hook**
```typescript
// app/hooks/useGuideTracking.ts (207줄)
export function useGuideTracking() {
  const [tracker] = useState<GuideTracker>(() => ({
    sessionId: `session_${Date.now()}_${Math.random()}`,
    startTime: Date.now(),
    currentStep: 0,
    stepStartTime: Date.now(),
    errors: []
  }));

  return {
    trackStepProgress,    // 단계 진행
    trackError,          // 에러 발생
    trackCompletion,     // 가이드 완료
    trackHelpView,       // 도움말 조회
    sessionId,
    fingerprint
  };
}
```

#### b) **Backend - API Endpoint**
```typescript
// app/api/guide-tracking/route.ts
POST /api/guide-tracking
- action: start_session | step_progress | track_error | complete_guide | session_end | view_help
- session_id: string
- data: 각 액션별 데이터
```

#### c) **Guide 페이지 통합**
```typescript
// app/guide/page.tsx
const { trackStepProgress, trackError, trackCompletion } = useGuideTracking();

// 페이지 로드 시
useEffect(() => {
  trackStepProgress(0, 'guide_page_loaded');
}, []);

// 단계 완료 시
const handleStepComplete = (stepNumber) => {
  trackStepProgress(stepNumber, stepInfo.id);
  if (stepNumber === 6) {
    trackCompletion();
  }
};

// 에러 발생 시
if (buttonType === 'error') {
  trackError(`Step ${stepNumber} error: ${buttonText}`, context);
}
```

### 데이터 구조:

#### **guide_sessions 테이블**
```sql
- session_id: VARCHAR(100)          // 세션 고유 ID
- os: VARCHAR(50)                   // Mac, Windows 등
- browser: VARCHAR(50)              // Chrome, Safari 등
- device_type: VARCHAR(50)          // desktop, mobile, tablet
- referrer_source: TEXT             // 유입 경로
- user_fingerprint: VARCHAR(100)    // 브라우저 핑거프린트
- current_step: INTEGER             // 현재 단계 (0-6)
- highest_step_reached: INTEGER     // 최고 도달 단계
- step_times: JSONB                 // {"step1": 120, "step2": 180, ...}
- is_completed: BOOLEAN             // 완료 여부
- total_time_seconds: INTEGER       // 총 소요 시간
- errors: JSONB                     // [{step: 2, error: "...", timestamp: "..."}]
- created_at: TIMESTAMP             // 시작 시간
- last_activity_at: TIMESTAMP       // 마지막 활동
```

#### **guide_events 테이블** (선택사항)
```sql
- session_id: VARCHAR(100)
- event_type: VARCHAR(50)           // session_start, step_progress, error 등
- event_data: JSONB                 // 이벤트별 추가 데이터
- created_at: TIMESTAMP
```

### 추적되는 사용자 행동:

1. **세션 시작**
   - OS, 브라우저, 디바이스 타입 자동 감지
   - 유입 경로 (referrer) 기록
   - 브라우저 핑거프린트 생성

2. **단계별 진행**
   - 각 단계 도달 시간
   - 각 단계별 소요 시간
   - 최고 도달 단계 업데이트

3. **에러 추적**
   - 어느 단계에서 에러 발생
   - 에러 메시지 및 컨텍스트
   - 타임스탬프

4. **완료 추적**
   - 총 소요 시간
   - 에러 발생 횟수
   - 완료 시간

## 📈 3. 대시보드 시스템

### 구성:
```typescript
// app/dashboard/page.tsx
- 실시간 세션 데이터 조회
- 4개의 Supabase View 활용
- 이메일 인증 보호 (me@jongjinchoi.com)
```

### Supabase Views:

#### 1. **today_metrics** - 오늘의 핵심 지표
```sql
- total_sessions: 오늘 총 세션
- completions: 오늘 완료 수
- completion_rate: 완료율 (%)
- avg_completion_minutes: 평균 완료 시간
- immediate_bounces: 즉시 이탈
```

#### 2. **step_funnel** - 단계별 퍼널 (7일)
```sql
- step: 단계 (0-6)
- users_reached: 도달 사용자
- dropped_off: 이탈 사용자
- dropout_rate: 이탈률 (%)
```

#### 3. **os_performance** - OS별 성능
```sql
- os: 운영체제
- total_attempts: 시도 횟수
- completions: 완료 횟수
- success_rate: 성공률 (%)
- avg_time_minutes: 평균 시간
```

#### 4. **common_errors** - 자주 발생하는 에러
```sql
- error_type: 에러 종류
- error_step: 발생 단계
- occurrence_count: 발생 횟수
```

## 🔐 4. 보안 및 접근 제어

### 대시보드 보안:
1. **이메일 인증 시스템**
   - 허용된 이메일: me@jongjinchoi.com
   - 6자리 인증 코드 발송
   - 10분 만료
   - 30일간 로그인 유지

2. **미들웨어 보호**
   ```typescript
   // middleware.ts
   - /dashboard/* 경로 보호
   - 인증 쿠키 확인
   - 미인증 시 /dashboard-login 리다이렉트
   ```

## 📍 5. 데이터 흐름

```
사용자 행동 → Frontend Hook → API Endpoint → Supabase
                    ↓
              Google Analytics
                    ↓
             대시보드에서 조회
```

### 실시간 추적 프로세스:
1. 사용자가 가이드 페이지 방문
2. `useGuideTracking` 훅이 세션 시작
3. 각 단계 진행 시 API 호출
4. Supabase에 실시간 저장
5. 대시보드에서 즉시 확인 가능

## 🎨 6. 시스템의 장점

1. **단순함**: 필요한 기능만 구현
2. **독립성**: GA4와 Guide Tracking이 서로 독립
3. **실시간성**: 즉시 데이터 확인 가능
4. **확장성**: 새로운 이벤트 추가 용이
5. **보안성**: 민감한 데이터는 인증 필요

## 🚧 7. 한계점 및 개선 가능 사항

1. **이메일 발송**: 현재는 콘솔 출력만 (실제 발송 미구현)
2. **데이터 보존**: 오래된 데이터 정리 정책 없음
3. **시각화**: 텍스트 기반 대시보드 (차트 없음)
4. **알림**: 특정 이벤트 발생 시 알림 없음

## 📋 8. 파일 구조 요약

```
app/
├── hooks/
│   └── useGuideTracking.ts      # 가이드 추적 Hook
├── api/
│   ├── guide-tracking/          # 추적 API
│   ├── send-auth-code/          # 인증 코드 발송
│   └── verify-auth-code/        # 인증 코드 확인
├── dashboard/
│   └── page.tsx                 # 대시보드
├── dashboard-login/
│   └── page.tsx                 # 로그인 페이지
├── components/
│   └── AnalyticsProvider.tsx    # GA4 페이지 추적
└── types/
    └── analytics-minimal.ts      # 최소 타입 정의

Supabase:
├── guide_sessions (테이블)
├── guide_events (테이블, 선택사항)
├── auth_codes (테이블)
├── today_metrics (뷰)
├── step_funnel (뷰)
├── os_performance (뷰)
└── common_errors (뷰)
```

## 🎯 결론

현재 시스템은 **"필요한 것만, 잘 작동하게"** 라는 원칙으로 구성되어 있습니다.
- GA4: 일반적인 웹 분석
- Guide Tracking: 가이드 특화 상세 분석
- 대시보드: 실시간 모니터링

복잡한 기존 시스템 대비 70% 코드 감소, 유지보수 용이성 대폭 향상되었습니다.