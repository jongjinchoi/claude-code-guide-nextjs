# Supabase 데이터 수집 시스템 완전 레퍼런스

> **⚠️ 중요**: 이 문서는 JS 최적화나 코드 수정 시 데이터 추적 시스템을 보호하기 위한 필수 참고 자료입니다.

## 📋 목차

1. [전체 데이터 수집 구조](#전체-데이터-수집-구조)
2. [27개 컬럼 상세 분석](#27개-컬럼-상세-분석)
3. [절대 변경 금지 요소들](#절대-변경-금지-요소들)
4. [위험도별 분류](#위험도별-분류)
5. [OS 토글 모듈화 특별 주의사항](#os-토글-모듈화-특별-주의사항)
6. [체크리스트](#체크리스트)

---

## 전체 데이터 수집 구조

### 데이터 흐름
```
사용자 액션 → DOM 이벤트 → Analytics.js → convertToSupabaseFormat() → Supabase raw_events 테이블
                                    ↓ 실패시
                              Google Apps Script 폴백
```

### 주요 구성 요소
- **Analytics.js**: 중앙 데이터 수집 엔진
- **Batch-analytics.js**: 배치 처리 시스템
- **Supabase-client.js**: Supabase 연결
- **Session-manager.js**: 세션 관리

---

## 27개 컬럼 상세 분석

### 1. timestamp
- **수집 방법**: `analytics.js:333` - `new Date().toISOString()`
- **가능한 값**: ISO 8601 형식 (`2024-07-24T10:30:45.123Z`)
- **위험 요소**: 시스템 시간 의존

### 2. event_category
- **수집 방법**: `analytics.js:387-395` - `extractEventCategory()`
- **가능한 값**: `guide`, `page`, `error`, `feedback`, `session`, `interaction`, `other`
- **⚠️ 위험 요소**: 이 로직 수정 시 모든 이벤트 분류 실패

### 3. event_name
- **수집 방법**: 이벤트 추적 함수 호출 시 첫 번째 매개변수
- **가능한 값**: `page_view`, `guide_started`, `step_completed`, `button_click`, `code_copy` 등
- **위험 요소**: 이벤트명 오타 시 잘못된 데이터

### 4. user_id
- **수집 방법**: `analytics.js:442-461` - `getUserId()`
- **형식**: `user_{타임스탬프}_{랜덤문자열}_{브라우저핑거프린트}`
- **⚠️ 위험 요소**: localStorage 삭제 시 새 사용자로 인식

### 5. session_id
- **수집 방법**: `session-manager.js:14-28`
- **형식**: `session_{타임스탬프}_{랜덤문자열}`
- **위험 요소**: sessionStorage 의존

### 6. is_new_user
- **수집 방법**: localStorage + sessionStorage 조합 판단
- **가능한 값**: `true`, `false`
- **위험 요소**: localStorage 삭제 시 기존 사용자도 신규로 인식

### 7. page_path
- **수집 방법**: `window.location.pathname`
- **가능한 값**: `/`, `/guide`, `/about`, `/faq`
- **위험 요소**: URL 구조 변경 시 경로 값 변경

### 8. referrer_source
- **수집 방법**: `analytics.js:398-411` - `extractReferrerSource()`
- **가능한 값**: `direct`, `google`, `facebook`, `twitter`, `github`, hostname
- **위험 요소**: 새로운 플랫폼 추가 시 hostname으로만 분류

### 9. referrer_medium
- **수집 방법**: `analytics.js:414-426` - `extractReferrerMedium()`
- **가능한 값**: `none`, `organic`, `social`, `referral`, `unknown`
- **위험 요소**: 매체 분류 로직 변경 시 영향

### 10. guide_step_number
- **수집 방법**: `guide-manager.js:366-382` - `getStepNumber()`
- **가능한 값**: `1-6`, `null`
- **위험 요소**: 단계 순서 변경 시 번호 불일치

### 11. guide_step_name
- **수집 방법**: 하드코딩된 단계명
- **가능한 값**: `start`, `homebrew`, `node`, `claude`, `auth`, `project` (OS별 변형 포함)
- **위험 요소**: 단계명 변경 시 데이터 불일치

### 12. guide_progress
- **수집 방법**: 계산된 진행률
- **가능한 값**: `0-100`, `null`
- **위험 요소**: 진행률 계산 오류

### 13. time_on_step
- **수집 방법**: `guide-manager.js:25-26` - `getTotalActiveMinutes()`
- **가능한 값**: 양의 정수 (분), `null`
- **위험 요소**: 시간 계산 로직 수정 시 부정확

### 14. action_type
- **수집 방법**: `data.button_purpose || data.button_type`
- **가능한 값**: `start_guide`, `confirm_step_success`, `switch_os_instructions` 등
- **⚠️ 위험 요소**: 버튼 구조 변경 시 누락

### 15. action_target
- **수집 방법**: `data.button_text || data.button_id || data.button_location`
- **가능한 값**: 버튼 텍스트, ID, 위치
- **위험 요소**: DOM 구조 변경 시 정보 변경

### 16. action_value
- **수집 방법**: `data.button_category || data.code_category`
- **가능한 값**: `cta`, `guide_progress`, `personalization`, `installation` 등
- **위험 요소**: 카테고리 분류 체계 변경

### 17. interaction_count
- **수집 방법**: 항상 `1`로 고정
- **가능한 값**: `1`
- **위험 요소**: 없음 (현재 의미없는 컬럼)

### 18. device_category
- **수집 방법**: `analytics.js:507-523` - `getDevice()`
- **가능한 값**: `Mobile`, `Tablet`, `Desktop`
- **위험 요소**: User Agent 변경 시 잘못된 감지

### 19. os
- **수집 방법**: `analytics.js:486-494` - `getOS()`
- **가능한 값**: `Windows`, `MacOS`, `Linux`, `Android`, `iOS`, `Unknown`
- **⚠️ 위험 요소**: User Agent 변경 시 OS 감지 실패

### 20. browser
- **수집 방법**: `analytics.js:497-504` - `getBrowser()`
- **가능한 값**: `Chrome`, `Safari`, `Firefox`, `Edge`, `Unknown`
- **위험 요소**: User Agent 변경 시 브라우저 감지 실패

### 21. is_success
- **수집 방법**: `data.error_type ? false : true`
- **가능한 값**: `true`, `false`
- **위험 요소**: 에러 처리 로직 변경 시 잘못된 판단

### 22. error_type
- **수집 방법**: 에러 이벤트에서 명시적 설정
- **가능한 값**: 에러 타입 문자열, `null`
- **위험 요소**: 에러 분류 체계 변경

### 23. error_message
- **수집 방법**: 에러 메시지 직접 전달
- **가능한 값**: 에러 메시지, `null`
- **위험 요소**: 메시지 형식 변경

### 24. feedback_score
- **수집 방법**: `analytics.js:429-438` - `emojiToScore()`
- **가능한 값**: `5` (😍), `4` (😊), `3` (😐), `2` (😕), `null`
- **⚠️ 위험 요소**: 이모지 매핑 변경 시 점수 불일치

### 25. feedback_text
- **수집 방법**: 사용자 입력 텍스트 직접 전달
- **가능한 값**: 사용자 텍스트, `null`
- **위험 요소**: 피드백 폼 구조 변경

### 26. total_time_minutes
- **수집 방법**: `data.completion_time_minutes || data.total_duration`
- **가능한 값**: 양의 숫자 (분), `null`
- **위험 요소**: 시간 계산 로직 수정

---

## 🔴 절대 변경 금지 요소들

### Analytics.js 핵심 함수들 (전체 시스템 중단 위험)
```javascript
// analytics.js 내 절대 수정 금지
convertToSupabaseFormat()    // 293-328행: 전체 데이터 변환
getUserId()                  // 442-461행: 사용자 ID 생성  
extractEventCategory()       // 387-395행: 이벤트 분류
extractReferrerSource()      // 398-411행: 레퍼러 소스 분류
extractReferrerMedium()      // 414-426행: 레퍼러 매체 분류
emojiToScore()              // 429-438행: 피드백 점수 변환
getOS()                     // 486-494행: OS 감지
getBrowser()                // 497-504행: 브라우저 감지
getDevice()                 // 507-523행: 디바이스 감지
```

### 필수 클래스명/속성 (데이터 수집 중단 위험)
```css
/* 버튼 추적용 - 절대 변경 금지 */
.result-btn[data-step][data-result]  /* guide_step_name, action_type */
.copy-btn                            /* code_copy 이벤트 */
.os-toggle                          /* switch_os_instructions */
.emoji-btn[data-emoji]              /* feedback_score 계산 */
.cta-button, .cta-btn               /* CTA 추적 */
.complete-step-btn                   /* 단계 완료 */
.theme-toggle                       /* 다크모드 토글 */
.font-size-btn                      /* 폰트 크기 조절 */
.faq-question                       /* FAQ 확장 */
```

### 필수 DOM 구조
```html
<!-- 가이드 단계 구조 - 절대 변경 금지 -->
<div class="step-section" id="step-homebrew" data-os="mac">
  <div class="step-header">
    <div class="step-number">2</div>
    <h2>단계 제목</h2>
  </div>
  <div class="step-content">
    <button class="result-btn" data-step="homebrew" data-result="success">성공</button>
  </div>
</div>
```

### 필수 localStorage/sessionStorage 키
```javascript
// 절대 변경 금지
'claude_guide_user_id'        // 사용자 ID
'claude_guide_visited'        // 첫 방문 여부  
'claude_guide_session_id'     // 세션 ID
'is_new_user_session'         // 신규 사용자 세션
```

---

## 위험도별 분류

### 🔴 **높은 위험 (전체 데이터 수집 중단)**
- Analytics.js 핵심 함수 수정
- Supabase 연결 설정 변경
- Session Manager 로직 변경
- 필수 클래스명 제거

### 🟡 **중간 위험 (데이터 품질 저하)**
- DOM 구조 변경
- 버튼 텍스트/ID 변경
- User Agent 의존 로직 수정
- 하드코딩된 분류 체계 변경

### 🟢 **낮은 위험 (부분적 영향)**
- UI 스타일 변경
- 버튼 위치 이동
- 텍스트 내용 변경 (버튼 텍스트 제외)

---

## 🎯 OS 토글 모듈화 특별 주의사항

### 현재 OS 토글이 수집하는 데이터
```javascript
{
  event_name: "button_click",
  event_category: "interaction", 
  action_type: "switch_os_instructions",
  action_target: "macOS", // 버튼 텍스트
  action_value: "personalization",
  button_category: "personalization",
  button_purpose: "switch_os_instructions",
  is_useful: true
}
```

### HeaderControls 모듈화 시 필수 유지사항
1. **`.os-toggle` 클래스** 유지 (analytics.js:589-592에서 감지)
2. **버튼 텍스트** 유지 (`"macOS"`, `"Windows"`)
3. **DOM 클릭 이벤트** 유지 (커스텀 이벤트 사용 금지)
4. **data-os 속성** 업데이트 (현재 OS 상태 추적용)

### 안전한 모듈화 방법
```tsx
// HeaderControls.tsx - 안전한 구현 예시
<button className="os-toggle" id="osToggle" onClick={handleOSToggle}>
  <span className="os-text" id="currentOS">macOS</span>
  <i className="fas fa-exchange-alt"></i>
</button>

// OS 전환 시 data-os 속성 업데이트 필수
const handleOSToggle = () => {
  // ... OS 전환 로직
  document.querySelector('.guide-content')?.setAttribute('data-os', newOS);
}
```

---

## ✅ 체크리스트

### JS 최적화/코드 수정 전 필수 확인사항

#### 🔍 **Analytics.js 관련**
- [ ] `convertToSupabaseFormat()` 함수 건드리지 않음
- [ ] `getUserId()` 함수 건드리지 않음  
- [ ] 이벤트 분류 함수들 건드리지 않음
- [ ] OS/브라우저/디바이스 감지 함수 건드리지 않음

#### 🔍 **DOM 구조 관련**
- [ ] `.result-btn[data-step][data-result]` 구조 유지
- [ ] `.os-toggle` 클래스명 유지
- [ ] `.copy-btn` 클래스명 유지
- [ ] 가이드 단계 DOM 구조 유지
- [ ] 필수 data-* 속성들 유지

#### 🔍 **이벤트 추적 관련**
- [ ] 기존 클릭 이벤트 구조 유지
- [ ] 커스텀 이벤트로 대체하지 않음
- [ ] 버튼 텍스트 변경하지 않음
- [ ] 이벤트명 오타 없음

#### 🔍 **저장소 관련**
- [ ] localStorage 키명 변경하지 않음
- [ ] sessionStorage 키명 변경하지 않음
- [ ] 데이터 형식 호환성 유지

#### 🔍 **OS 토글 모듈화 관련**
- [ ] `.os-toggle` 클래스 유지
- [ ] 버튼 텍스트 `"macOS"`, `"Windows"` 유지
- [ ] `data-os` 속성 업데이트 로직 추가
- [ ] DOM 클릭 이벤트 방식 유지

### 테스트 방법
```javascript
// 브라우저 개발자 도구에서 확인
console.log('Analytics 로드됨:', typeof window.Analytics);
console.log('사용자 ID:', localStorage.getItem('claude_guide_user_id'));
console.log('세션 ID:', sessionStorage.getItem('claude_guide_session_id'));

// OS 토글 클릭 후 네트워크 탭에서 Supabase 요청 확인
// 예상 데이터: action_type: "switch_os_instructions"
```

---

## 🚨 비상 연락처

**데이터 수집 중단 발견 시:**
1. 즉시 이전 버전으로 롤백
2. 브라우저 개발자 도구에서 에러 확인
3. Supabase 대시보드에서 데이터 수집 상태 확인
4. 필요시 Google Apps Script 폴백 확인

**이 문서 업데이트 시기:**
- Analytics.js 수정 시
- 새로운 이벤트 추가 시  
- DOM 구조 대규모 변경 시
- Supabase 스키마 변경 시

---

*마지막 업데이트: 2024-07-24*
*작성자: Claude Code (AI Assistant)*