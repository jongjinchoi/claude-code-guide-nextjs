# AnalyticsProvider 최적화 가이드

## 🚨 현재 문제점

### GA4 이벤트 한도
- 무료 버전: 일일 이벤트 10만개 제한
- 월간 이벤트: 1000만개 제한
- 초과 시 데이터 손실 발생

### 현재 이벤트 발생 패턴
```
사용자 1명이 5페이지 방문 시:
- page_view: 5개 (GA4 자동)
- page_exit: 5개 (우리가 추가)
- page_blur: 3-5개 (모바일)
= 총 13-15개 이벤트/사용자
```

일일 1,000명 방문 시 = 13,000-15,000 이벤트

## 🎯 최적화 전략

### 1. **최소 시간 필터링**
```javascript
// 현재: 모든 페이지 이탈 기록
// 개선: 의미 있는 체류만 기록
const MIN_TIME_ON_PAGE = 5; // 5초 이상만
const MIN_BLUR_TIME = 10;   // blur는 10초 이상만
```

**효과**: 바운스 방문자 제외로 ~30% 이벤트 감소

### 2. **중요 페이지 우선순위**
```javascript
const IMPORTANT_PAGES = ['/guide', '/'];

// 중요 페이지: 3초부터 추적
// 일반 페이지: 5초부터 추적
const minTime = isImportantPage ? 3 : 5;
```

**효과**: 덜 중요한 페이지 이벤트 ~20% 감소

### 3. **샘플링 적용**
```javascript
const SAMPLE_RATE = 0.5; // 50% 사용자만 추적

// 중요 페이지는 100%, 나머지는 샘플링
const shouldTrack = isImportantPage || Math.random() < SAMPLE_RATE;
```

**효과**: 전체 이벤트 ~40% 감소 (중요 데이터는 보존)

### 4. **시간 버킷팅**
```javascript
// 현재: time_on_page: 127 (정확한 초)
// 개선: time_bucket: "2-3m" (범위로 그룹화)

function getTimeBucket(seconds) {
  if (seconds < 10) return '0-10s';
  if (seconds < 30) return '10-30s';
  // ...
}
```

**효과**: GA4에서 집계 효율성 향상

### 5. **모바일 전용 blur 추적**
```javascript
// 데스크톱에서는 blur 이벤트 제외
if (isMobileDevice()) {
  window.addEventListener('blur', handleBlur);
}
```

**효과**: 데스크톱 blur 이벤트 ~60% 감소

### 6. **디바운스 & 배치 처리**
```javascript
// 1초 내 중복 이벤트 방지
const DEBOUNCE_DELAY = 1000;

// 여러 이벤트를 모아서 전송
const BATCH_EVENTS = true;
```

**효과**: 빠른 페이지 전환 시 중복 제거

## 📊 최적화 결과 예상

### Before (현재)
```
일일 1,000명 방문:
- page_exit: 5,000개
- page_blur: 3,000개
- 기타: 5,000개
= 총 13,000개 이벤트/일
```

### After (최적화 후)
```
일일 1,000명 방문:
- page_exit: 2,500개 (50% 감소)
- page_blur: 600개 (80% 감소)
- 기타: 5,000개
= 총 8,100개 이벤트/일 (38% 감소)
```

## 🔧 구현 방법

### Option 1: 전체 교체
```javascript
// 기존 AnalyticsProvider.tsx를 
// AnalyticsProvider-optimized.tsx로 교체
```

### Option 2: 점진적 적용
```javascript
// 1단계: 최소 시간만 적용
if (duration >= 5) {
  window.gtag('event', 'page_exit', {...});
}

// 2단계: 중요 페이지 구분 추가
// 3단계: 샘플링 적용
```

### Option 3: 환경 변수로 제어
```javascript
const MIN_TIME = process.env.NEXT_PUBLIC_MIN_TRACKING_TIME || 5;
const SAMPLE_RATE = process.env.NEXT_PUBLIC_SAMPLE_RATE || 1.0;
```

## 📈 추가 최적화 아이디어

### 1. **스마트 샘플링**
- 신규 사용자: 100% 추적
- 재방문자: 30% 추적
- 가이드 완료자: 추적 중단

### 2. **시간대별 조정**
- 피크 시간: 샘플링 강화
- 새벽 시간: 전체 추적

### 3. **이벤트 통합**
```javascript
// 여러 이벤트를 하나로
window.gtag('event', 'page_interaction', {
  exit_type: 'navigation',
  blur_count: 3,
  total_time: 145,
  // 한 번에 여러 정보 전송
});
```

### 4. **로컬 집계**
```javascript
// 클라이언트에서 집계 후 전송
const summary = {
  pages_viewed: 5,
  total_time: 520,
  blur_events: 3
};
// 세션 종료 시 한 번만 전송
```

## ⚖️ 트레이드오프

### 얻는 것:
✅ GA4 할당량 절약
✅ 더 깔끔한 데이터
✅ 비용 절감 (유료 전환 지연)
✅ 성능 개선

### 잃는 것:
❌ 일부 사용자 데이터 누락
❌ 정밀도 감소
❌ 짧은 방문 추적 불가
❌ 복잡성 증가

## 🎯 권장사항

1. **즉시 적용**: 최소 시간 필터 (5초)
2. **단계적 적용**: 중요 페이지 구분
3. **모니터링 후**: 샘플링 비율 조정
4. **필요시만**: 배치 처리

가장 간단한 시작:
```javascript
// AnalyticsProvider.tsx 수정
if (duration >= 5) { // 이 한 줄만 추가
  window.gtag('event', 'page_exit', {...});
}
```

이것만으로도 30-40% 이벤트 감소 효과!