#!/bin/bash

# Script to find unused files

echo "Finding unused TypeScript/JavaScript/CSS files..."
echo "================================================"

# Create an array to store unused files
unused_files=()

# Function to check if a file is imported
check_file_usage() {
    local file="$1"
    local filename=$(basename "$file")
    local filename_no_ext="${filename%.*}"
    
    # Skip checking for the main entry files
    if [[ "$file" == "./app/layout.tsx" ]] || [[ "$file" == "./app/page.tsx" ]] || [[ "$file" == "./next.config.ts" ]] || [[ "$file" == "./middleware.ts" ]] || [[ "$file" == "./next-env.d.ts" ]]; then
        return 0
    fi
    
    # For CSS files, check for import statements
    if [[ "$file" == *.css ]]; then
        # Check if imported anywhere
        if ! grep -r "import.*['\"].*$(basename "$file")['\"]" . --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=backup -q 2>/dev/null; then
            # Also check for direct CSS imports in globals.css
            if ! grep -F "@import" ./app/styles/globals.css | grep -F "$(basename "$file")" -q 2>/dev/null; then
                return 1
            fi
        fi
    else
        # For TS/JS files, check various import patterns
        local patterns=(
            "from ['\"].*${filename_no_ext}['\"]"
            "import ['\"].*${filename_no_ext}['\"]"
            "require\(['\"].*${filename_no_ext}['\"]"
            "from ['\"].*$(basename "$file")['\"]"
            "import ['\"].*$(basename "$file")['\"]"
        )
        
        # Check each pattern
        local found=0
        for pattern in "${patterns[@]}"; do
            if grep -r "$pattern" . --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" --include="*.css" --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=backup -q 2>/dev/null; then
                found=1
                break
            fi
        done
        
        if [[ $found -eq 0 ]]; then
            return 1
        fi
    fi
    
    return 0
}

# Process each file
while IFS= read -r file; do
    if ! check_file_usage "$file"; then
        unused_files+=("$file")
    fi
done < <(find . -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.css" \) -not -path "./node_modules/*" -not -path "./backup/*" -not -path "./.next/*" | sort)

# Output results
if [ ${#unused_files[@]} -eq 0 ]; then
    echo "No unused files found!"
else
    echo "Found ${#unused_files[@]} potentially unused files:"
    echo
    for file in "${unused_files[@]}"; do
        echo "  $file"
    done
fi