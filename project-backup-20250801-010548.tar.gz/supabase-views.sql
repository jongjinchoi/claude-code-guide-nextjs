-- 오늘의 핵심 지표
CREATE OR REPLACE VIEW today_metrics AS
SELECT
  COUNT(*) as total_sessions,
  COUNT(*) FILTER (WHERE is_completed = true) as completions,
  ROUND(COUNT(*) FILTER (WHERE is_completed = true) * 100.0 / NULLIF(COUNT(*), 0), 1) as completion_rate,
  AVG(total_time_seconds) FILTER (WHERE is_completed = true) / 60 as avg_completion_minutes,
  COUNT(*) FILTER (WHERE highest_step_reached = 0) as immediate_bounces
FROM guide_sessions
WHERE DATE(created_at) = CURRENT_DATE;

-- 단계별 이탈 분석
CREATE OR REPLACE VIEW step_funnel AS
WITH step_analysis AS (
  SELECT
    highest_step_reached as step,
    COUNT(*) as users_reached
  FROM guide_sessions
  WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
  GROUP BY highest_step_reached
)
SELECT
  step,
  users_reached,
  LAG(users_reached) OVER (ORDER BY step) - users_reached as dropped_off,
  ROUND((LAG(users_reached) OVER (ORDER BY step) - users_reached) * 100.0 /
    NULLIF(LAG(users_reached) OVER (ORDER BY step), 0), 1) as dropout_rate
FROM step_analysis
ORDER BY step;

-- OS별 성공률
CREATE OR REPLACE VIEW os_performance AS
SELECT
  os,
  COUNT(*) as total_attempts,
  COUNT(*) FILTER (WHERE is_completed = true) as completions,
  ROUND(COUNT(*) FILTER (WHERE is_completed = true) * 100.0 / NULLIF(COUNT(*), 0), 1) as success_rate,
  AVG(total_time_seconds) FILTER (WHERE is_completed = true) / 60 as avg_time_minutes
FROM guide_sessions
WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY os
ORDER BY total_attempts DESC;

-- 에러 패턴 분석
CREATE OR REPLACE VIEW common_errors AS
SELECT
  error_data->>'error' as error_type,
  error_data->>'step' as error_step,
  COUNT(*) as occurrence_count
FROM guide_sessions,
LATERAL jsonb_array_elements(errors) as error_data
WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY error_type, error_step
ORDER BY occurrence_count DESC
LIMIT 10;